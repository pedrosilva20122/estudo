



// Para exibir o box flutuante



 $(document).ready(function() {
   $('#abr').on('click',function(e){
     e.preventDefault(); 
       $('#divprin').fadeIn();

// Para ocultar o box flutuante
$('#fechar').on('click',function(e){
  e.preventDefault();
   $('#divprin').fadeOut();
});
 });
  });



