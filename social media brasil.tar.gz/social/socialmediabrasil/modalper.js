 // Para exibir o box flutuante



 $(document).ready(function() {
   $('#uploadper').on('click',function(e){
     e.preventDefault(); 
       $('#per').fadeIn();

// Para ocultar o box flutuante
$('#fr').on('click',function(e){
  e.preventDefault();
   $('#per').fadeOut();
});
 });
  });