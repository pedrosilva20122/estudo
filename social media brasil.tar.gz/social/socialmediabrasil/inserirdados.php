<?php

//recebe os valores do formulario
$nome = $_POST['nome'];
$sobrenome = $_POST['sobrenome'];
$dia = $_POST['dia'];
$mes = $_POST['mes'];
$ano = $_POST['ano'];
$genero = $_POST['genero'];
$email = $_POST['email'];
$senha = $_POST['senha'];

//verifica se existe conex�o com bd, caso n�o tenta criar uma nova
$conectar = mysqli_connect("localhost:3306","root","","cadrastro") //porta, usu�rio, senha
or die("Erro na conex�o com banco de dados"); //caso n�o consiga conectar mostra a mensagem de erro mostrada na conex�o
//ajusta o charset de comunica��o entre a aplica��o e o banco de dados
mysqli_set_charset($conectar,'utf8'); 
//Abaixo atribu�mos os valores provenientes do formul�rio pelo m�todo POST
//String com consulta SQL da inser��o
$adiciona =   "INSERT INTO usuarios (id,nome,sobrenome,dia,mes,ano,genero,email,senha) VALUES (null,'$nome','$sobrenome','$dia','$mes','$ano','$genero','$email','$senha')"; 
$adiciona = mysqli_query($conectar, $adiciona);

?>


<?php

    //Destr�i
    session_destroy();
    //Limpa
    unset ($_SESSION['email']);
    unset ($_SESSION['senha']);
    //Redireciona para a p�gina de autentica��o
    header('location:index.html');    



?>




 function saudacao( $nome = '' ) {
	date_default_timezone_set('America/Sao_Paulo');
	$hora = date('H');
	if( $hora >= 6 && $hora <= 12 )
		return 'Bom dia' . (empty($nome) ? '' : ', ' . $nome);
	else if ( $hora > 12 && $hora <=18  )
		return 'Boa tarde' . (empty($nome) ? '' : ', ' . $nome);
	else
		return 'Boa noite' . (empty($nome) ? '' : ', ' . $nome);
   
}
echo saudacao( '' );


while ($dadousu = mysqli_fetch_object($consulta)){
   
       
    echo "<ul></li><cite>,&nbsp</cite>" . $dadousu->nome . "&nbsp".$dadousu->sobrenome ."</li></ul>";
 
}
