<?php

$conectar = mysqli_connect("localhost:3306","root","","cadrastro") // faz a conexão com o banco de dados. 
        or die("Erro na coxexão com o banco de dados");// caso não consiga conectar mostra a mensagem de erro mostrada na conexão.
//ajusta a conexão com o banco de dados e a aplicação.
mysqli_set_charset($conectar,"UTF-8");
//se o usuáario clicou no botão foto de perfil altera a foto.
if(isset($_POST['foto'])){
//recupera os dados do upload.
    $foto = $_FILES['foto'];    
//se a foto estiver sido selecionado guarda o nome
    if (!empty($foto['name'])){
 // tamanho,largura,altura
        $largura = 200;
        $altura = 300;
        $tamanho = 10240;
//fim
$erro = array();
//verifica se o arquivo é uma imagem.
if(!preg_match("/^image\/(pjpeg|jpeg|png|gif|bmp)$/", $foto["type"])){
    $erro[1] = "Isso não é uma imagem.";
}
//pega as dimensões da imagem.
$dimensoes = getimagesize($foto['tmp_name']);
//verifica se a largura da imagem é maior que a largura permitida.
if($dimensoes[0]> $largura){
    $error[2] = "A largura da imagem não deve ultrapassar".$largura."pixels";    
}
//Verifica se a altura da imagem é maior que a altura permitida.
if($dimensoes[1]> $altura){
    $error[3] = "A altura da imagem não deve ultrapassar".$altura."pixels";
}
//verifica se o tamanho da imagem é maior que o tamanho permitido.
if($foto["size"]> $tamanho){
    $error[4] = "A imagem deve ter bo máximo".$tamanho."bytes";
}
//se não houver nenhum erro
if(count($erro) == 0 ){
//pega a extensão da imagem
            preg_match("/\.(gif|bmp|png|jpg|jpeg){1}$/i", $foto["name"],$ext);
//Gera uma nome único para a imagem.
$nome_imagem = md5(uniqid(time())).".". $ext[1];
//Caminho de onde ficará a imagem.
$caminho_imagem = "/.perfil/" . $nome_imagem;
//Faz o upload da imagem para seu respectivo caminho
            move_uploaded_file($foto["tmp_name"], $caminho_imagem);
//Insere a foto no banco de dados
            $adiciona = "INSERT INTO usuarios (id,foto) VALUES ('','".$nome_imagem."')";
                    $adiciona = mysqli_query($conectar, $adiciona);
//se adicionado com sucesso exibe a mensagem
     if ($adiciona){
echo "Postado com sucesso.";
header("Location: principal.php");
}
}

//se houver mensagens de erro, exibe-as
if (count($error) != 0 ){
foreach ($error as $erro) {
echo $erro .  "<br/>";
}
}
}
}
?>
   

