
﻿<?php
//include('logar.php');


//verifica se ouve o POST e se o usuário ou a senha é(são) vazio(s)
if (!empty($_POST) AND (empty($_POST['login']) OR empty($_POST['password']))) {
    header("Location: index.html"); exit;
}

//verifica se existe conexão com bd, caso não tenta criar uma nova
$conectar = mysqli_connect("localhost:3306","root","","cadrastro") //porta, usuário, senha
or die("Erro na conexão com banco de dados"); //caso não consiga conectar mostra a mensagem de erro mostrada na conexão
//ajusta o charset de comunicação entre a aplicação e o banco de dados
mysqli_set_charset($conectar,'utf8');

                              
                         		
# Validar os dados do usuário
function anti_sql_injection($string)
	{
		include('logar.php');
		$string = stripslashes($string);
		$string = strip_tags($string);
		$string = mysqli_real_escape_string($conectar,$string);
		return $string;
	}
//faz a pesquisa do usuario no banco de dados
$sql = mysqli_query($conectar,"SELECT id email, senha FROM usuarios WHERE  email='".anti_sql_injection($_POST['login'])."' and senha='".anti_sql_injection($_POST['password'])."' limit 1");
$linhas = mysqli_num_rows($sql); 

//se os dados bater entra se nao retorna
if($linhas == 0)
	{		
	    // Mensagem de erro quando os dados são inválidos e/ou o usuário não foi encontrado
       echo '<div class="msg2 padding20">Usuário não encontrado ou usuário e senha inválidos.</div>';          
        }
else
{
    // Salva os dados encontados na variável $Dados
		while($dados = mysqli_fetch_assoc($sql)); 
			{
//Se a sessão não existir, inicia uma			    
if (!isset($_SESSION)) session_start();	
//Salva os dados encontrados na sessão
				 $_SESSION['id'] = $dados['id'];
				 $_SESSION['nome'] = $dados['nome'];
                                 $_SESSION['sobrenome'] = $dados['sobrenome'];
				 $_SESSION['login'] = $_POST['login'];
                                
                //Redireciona para a pagina principral                
				header("Location: restrito.php");
			}
	}
        
        
        
?>