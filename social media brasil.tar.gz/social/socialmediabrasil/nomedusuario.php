<?php
//fAZ a conexão com a base de dados
$conectar = mysqli_connect("localhost:3306","root","","cadrastro")
or die("Erro na Conecxão com Base de Dados");
//Ajusta a comunicação do banco de dados com  a aplicação
mysqli_set_charset($conectar,'UTF-8');
//faz a consulta na tabela
$consulta = mysqli_query($conectar,"SELECT id, nome, sobrenome FROM usuarios WHERE id AND email= '". $_SESSION['login']."' ");
$listar = mysqli_fetch_array($consulta); {
    

 function saudacao2( $nome = '' ) {
	date_default_timezone_set('America/Sao_Paulo');
	$hora = date('H');
	if( $hora >= 6 && $hora <= 12 )
		return 'Bom dia' . (empty($nome) ? '' : ', ' . $nome);
	else if ( $hora > 12 && $hora <=18  )
		return 'Boa tarde' . (empty($nome) ? '' : ', ' . $nome);
	else
		return 'Boa noite' . (empty($nome) ? '' : ', ' . $nome);
   
}
echo saudacao2( '' );
    
    //Se a sessão não existir, inicia uma
    if (!isset($_SESSION)) {
        session_start();
    }
    //Salva os dados encontrados na sessão
    $_SESSION['id'] = $listar['id'];
    $_SESSION['nome'] = $listar['nome'];
    $_SESSION['sobrenome'] = $listar['sobrenome'];
    echo "<ul></li><cite>,&nbsp</cite>" . $listar['nome']. "&nbsp".$listar['sobrenome'] ."</li></ul>";
}
  


?>
 
        
        