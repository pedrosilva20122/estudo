
<?php
//verifica se existe conex�o com bd, caso n�o tenta criar uma nova
$conectar = mysqli_connect("localhost:3306","root","","cadrastro") //porta, usu�rio, senha
or die("Erro na conex�o com banco de dados"); //caso n�o consiga conectar mostra a mensagem de erro mostrada na conex�o
//ajusta o charset de comunica��o entre a aplica��o e o banco de dados
mysqli_set_charset($conectar,'utf8');
?>

