
   
    function PreviewImage() {
        
        
        var oFReader = new FileReader();
        oFReader.readAsDataURL(document.getElementById("uploadImage").files[0]);

        oFReader.onload = function (oFREvent) {
            document.getElementById("uploadPreview").src = oFREvent.target.result;
        };
    };
function arquivo(){
    document.getElementById("uploadImage").click();
}