<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script> 
<link rel="stylesheet" type="text/css" media="screen" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" />
<link rel="stylesheet" type="text/css" href="menu.css" media="all" />
<link rel="stylesheet" href="menulateral.css">
<!--<link rel="stylesheet" href="textareasocial.css">-->
<link rel="stylesheet" href="fotoperfil.css">
<link rel="stylesheet" href="postarflu.css">
<meta charset="utf-8">
<title>SISTEMA WEB</title>


		
</head>
<body>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>  
<script type="text/javascript" src="jquery-3.5.1.js"></script>
<script type="text/javascript" src="previzualizar.js"></script>
<script type="text/javascript" src="modalper.js"></script>  
<script type="text/javascript" src="postar.js"></script>   



<!--barra do topo-->
<nav  id="menu"class="menu">
<div class="navbar navbar-inverse navbar-fixed-top">
<div class="container">
<div class="navbar-header">
<ul>
<li><a href="#">Home</a></li>
<li><a href="#">Serviços</a></li>
<li><a href="#">Conteudo</a></li>
<li><a href="#">Contato</i></a></li>
<div  class="Text">
<li><input  id="Text"type="search" placeholder="Search" aria-label="Search"></li>
<li class="butt"><button type="submit">Search</button></li>
<div class="usu"><form method="POST" action="sair.php"><input type="submit"	value="Sair" name="sair"></form><div>
</ul>
</div>
</div>
</div>
</nav>
<!--fim-->


 
 <!--menulateral-->
<div id="menulateral" class="menulateral">
<ul>
<li class="active"><a href="#"><span>Novas Postagens</span></a></li>
<li class="last"><a href="#"><span>Amigos</span></a></li>
</ul>
<ul>
<li class="last"><a href="#"><span>Fotos</span></a></li>
<li class="last"><a href="#"><span>Notificações</span></a></li>
</ul>
<ul>
<li class="last"><a href="#"><span>Mensagens</span></a></li>
<li class="last"><a href="#"><span>Convidar Amigos</span></a></li>
<li class="last"><a href="#"><span>Grupos</span></a></li>
</ul>
</div>
<!--fim-->



    
<?php
  
      //Se a sessão não existir, inicia uma
      if (!isset($_SESSION)) {
        session_start();
    }
 
  


      
 
?>


<div class="post">
<form  action="tst.php" method="post" enctype="multipart/form-d>ata">
<ul class="postagens">
<li><textarea    name = "conteudo" id="txtpost"></textarea></li>
<li class="pt"><input type="submit" value="postar" name="postar" id="postar" ></li>
<li class="pt2"><input type="file" value="Foto" name="foto" ></li>
</ul>
</form>
</div>

<div class="fora">
<div class="agrupa"> 
        
<div class="boxmodal"id="uploadper"> <?php  include 'uploadfoto.php';?>
 <label class="avatar" for="btn"><img src="perfil/avatar.png/100/100" alt=""</label>          
</div>
<div class="texto" id="abr"><div class="nomedusuario"><?php  include 'nomedusuario.php';?>
</div>
</div>
</div>

    
    
   <div class="divbotoes">
       <div class="ftdiv" ></div>
       <div class="labelvideo">Live</div> 
       <div class="marcarpessoa"></div>
       <div class="labelfoto">Galeria</div>
       <div class="sentimento"></div>
       <div class="labelsentimento">Sentimento</div>
      </div>
</div>




<!--modal foto-->
<div  id="per" class="boxesconder"> 
 <div class="central">    
  <input type="button" class="frper" id="fr">           
 <div class="topo"> 
  </div>
 <div class="previw">
     <form class="previwfoto" action="api-url-here" method="post" encType="multipart/form-data">
        
         <img class="previzualizar" id="uploadPreview"  />
             
    </form>  
  </div> 
  
<div class="inferior" >
      
 <div class="btnarq" onclick="arquivo();"></div>   
 <form action='image/upload' method='post' encType="multipart/form-data"> 
<!--<input class="btn-arq" type="button" onclick="arquivo();"value="Perfil">-->
<input class="arquivo" id="uploadImage" type="file" name="myPhoto" onchange="PreviewImage();" hidden /> 
 </form>
  </div>  
    
</div> 
</div>
<!---->
 

<!--modal postagem-->
<div  id="divprin" class="esconder"> 
 <div class="divcen">    
  <input type="button" class="fecharpost" id="fechar">           
 <div class="divtop"> 
  </div>
 <div class="caixatexto">
     <input type="texto" class="caixatxt">   
  </div> 
<div class="divbottom" >
  </div>     
</div> 
</div>
<!---->


</body>
</html>





