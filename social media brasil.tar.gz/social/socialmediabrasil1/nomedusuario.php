<?php
//fAZ a conexão com a base de dados
$conectar = mysqli_connect("localhost:3306","root","aqwe4523","cadrastro") 
or die("Erro na Conecxão com Base de Dados");
//Ajusta a comunicação do banco de dados com  a aplicação
mysqli_set_charset($conectar,'UTF-8');
//faz a consulta na tabela
$consulta = mysqli_query($conectar,"SELECT id,nome,sobrenome FROM usuarios ORDER BY id,nome,sobrenome");



 function saudacao( $nome = '' ) {
	date_default_timezone_set('America/Sao_Paulo');
	$hora = date('H');
	if( $hora >= 6 && $hora <= 12 )
		return 'Bom dia' . (empty($nome) ? '' : ', ' . $nome);
	else if ( $hora > 12 && $hora <=18  )
		return 'Boa tarde' . (empty($nome) ? '' : ', ' . $nome);
	else
		return 'Boa noite' . (empty($nome) ? '' : ', ' . $nome);
   
}
echo saudacao( '' );

while($dados = mysqli_fetch_assoc($sql));
$userid = $dados->id;
{
    session_start();
    $_SESSION['id_usuario'] = $dados['id'];

while ($dadousu = mysqli_fetch_object($consulta)){
   
       
    echo "<ul></li><cite>,&nbsp</cite>" . $dadousu->nome . "&nbsp".$dadousu->sobrenome ."</li></ul>";
 
}
}

	

	
        





?>
 
