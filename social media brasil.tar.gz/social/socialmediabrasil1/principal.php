<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>   
<link rel="stylesheet" type="text/css" href="menu.css" media="all" />
<link rel="stylesheet" href="menulateral.css">
<!--<link rel="stylesheet" href="textareasocial.css">-->
<link rel="stylesheet" href="postarflu.css">
<meta charset="utf-8">
<title>SISTEMA WEB</title>


		
</head><body>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>  
<script type="text/javascript" src="jquery-3.5.1.js"></script>
<script type="text/javascript" src="postar.js"></script>   
<script language="javascript">
$(function(){
    var textArea = $('#content'),
    hiddenDiv = $(document.createElement('div')),
    content = null;
    
    textArea.addClass('noscroll');
    hiddenDiv.addClass('hiddendiv');
    
    $(textArea).after(hiddenDiv);
    
    textArea.on('keyup', function(){
        content = $(this).val();
        content = content.replace(/\n/g, '<br>');
        hiddenDiv.html(content + '<br class="lbr">');
        $(this).css('height', hiddenDiv.height());
    });
};
</script>


<!--barra do topo-->
<nav  id="menu"class="menu">
<div class="navbar navbar-inverse navbar-fixed-top">
<div class="container">
<div class="navbar-header">
<ul>
<li><a href="#">Home</a></li>
<li><a href="#">Serviços</a></li>
<li><a href="#">Conteudo</a></li>
<li><a href="#">Contato</i></a></li>
<div  class="Text">
<li><input  id="Text"type="search" placeholder="Search" aria-label="Search"></li>
<li class="butt"><button type="submit">Search</button></li>
<div class="usu"><h2>Olá,<?php session_start(); echo   $_SESSION['nome_usu_sessao'];
?></div></h2>
</ul>
</div>
</div>
</div>
</nav>
<!--fim-->


 
 <!--menulateral-->
<div id="menulateral" class="menulateral">
<ul>
<li class="active"><a href="#"><span>Novas Postagens</span></a></li>
<li class="last"><a href="#"><span>Amigos</span></a></li>
</ul>
<ul>
<li class="last"><a href="#"><span>Fotos</span></a></li>
<li class="last"><a href="#"><span>Notificações</span></a></li>
</ul>
<ul>
<li class="last"><a href="#"><span>Mensagens</span></a></li>
<li class="last"><a href="#"><span>Convidar Amigos</span></a></li>
<li class="last"><a href="#"><span>Grupos</span></a></li>
</ul>
</div>
<!--fim-->





<div class="post">
<form  action="tst.php" method="post" enctype="multipart/form-data">
<ul class="postagens">
<li><textarea    name = "conteudo" id="txtpost"></textarea></li>
<li class="pt"><input type="submit" value="postar" name="postar" id="postar" ></li>
<li class="pt2"><input type="file" value="Foto" name="foto" ></li>
</ul>
</form>
</div>

<div class="fora">
    <div class="agrupa">    
<div class="fotodiv">       
</div>
        <div class="texto" id="abr"><div class="nomedusuario"><?php  include 'nomedusuario.php';?>
</div></div>
    </div>
   <div class="divbotoes">
       <div class="ftdiv" ></div>
       <div class="labelvideo">Live</div> 
       <div class="marcarpessoa"></div>
       <div class="labelfoto">Galeria</div>
       <div class="sentimento"></div>
       <div class="labelsentimento">Sentimento</div>
      </div>
</div>

<div  id="divprin" class="esconder"> 
 <div class="divcen">    
  <input type="button" class="fecharpost" id="fechar">           
 <div class="divtop"> 
  </div>
 <div class="caixatexto">
     <input type="texto" class="caixatxt">   
  </div> 
<div class="divbottom" >
  </div>     
</div> 
</div>


    
    
<?php
//fAZ a conexão com a base de dados
$conectar = mysqli_connect("localhost:3306","root","","cadrastro") 
or die("Erro na Conecxão com Base de Dados");
//Ajusta a comunicação do banco de dados com  a aplicação
mysqli_set_charset($conectar,'UTF-8');
//faz a consulta na tabela

$consulta = mysqli_query($conectar,"SELECT id, nome, sobrenome FROM usuarios WHERE id AND email= '". $_SESSION['login']."' ");
$listar = mysqli_fetch_array($consulta); {
    

 function saudacao( $nome = '' ) {
	date_default_timezone_set('America/Sao_Paulo');
	$hora = date('H');
	if( $hora >= 6 && $hora <= 12 )
		return 'Bom dia' . (empty($nome) ? '' : ', ' . $nome);
	else if ( $hora > 12 && $hora <=18  )
		return 'Boa tarde' . (empty($nome) ? '' : ', ' . $nome);
	else
		return 'Boa noite' . (empty($nome) ? '' : ', ' . $nome);
   
}
echo saudacao( '' );

      //Se a sessão não existir, inicia uma
      if (!isset($_SESSION)) {
        session_start();
    }
    //Salva os dados encontrados na sessão
      $_SESSION['id'] = $listar['id'];
      $_SESSION['nome'] = $listar['nome'];
      $_SESSION['sobrenome'] = $listar['sobrenome'];
       echo "<ul></li><cite>,&nbsp</cite>" . $listar['nome']. "&nbsp".$listar['sobrenome'] ."</li></ul>";
  }


      
 
?>


</body>
</html>





