<?php

// Start of Zend Debugger v.

function debugger_print () {}

function get_call_stack () {}

function debugger_start_debug () {}

function debugger_connector_pid () {}

function debugger_connect () {}

function debugger_get_server_start_time () {}

function debugger_start_debug_mode () {}

function debugger_is_debug_mode_enabled () {}

function debugger_stop_debug_mode () {}

// End of Zend Debugger v.
