
﻿<?php
//include('logar.php');
session_start(); 
//verifica se existe conex�o com bd, caso n�o tenta criar uma nova
$conectar = mysqli_connect("localhost:3306","root","aqwe4523","cadrastro") //porta, usu�rio, senha
or die("Erro na conex�o com banco de dados"); //caso n�o consiga conectar mostra a mensagem de erro mostrada na conex�o
//ajusta o charset de comunica��o entre a aplica��o e o banco de dados
mysqli_set_charset($conectar,'utf8');

                              
                         		
# Validar os dados do usuário
function anti_sql_injection($string)
	{
		include('logar.php');
		$string = stripslashes($string);
		$string = strip_tags($string);
		$string = mysqli_real_escape_string($conectar,$string);
		return $string;
	}
//faz a pesquisa do usuario no banco de dados
$sql = mysqli_query($conectar,"SELECT id, email, senha FROM usuarios WHERE  email='".anti_sql_injection($_POST['login'])."' and senha='".anti_sql_injection($_POST['password'])."' limit 1");
$linhas = mysqli_num_rows($sql); 

//se os dados bater entra se nao retorna
if($linhas == 0)
	{		
       echo '<div class="msg2 padding20">Usuário não encontrado ou usuário e senha inválidos.</div>';          
        }
else
	{
		while($dados = mysqli_fetch_assoc($sql));
                $userid = $dados->id;
			{
				 $_SESSION['id'] = $dados;
                                 $_SESSION['nome_usu_sessao'] = $_POST['login'];
                                //Obtendo o id da sessão iniciada:
				header("Location: principal.php");
			}
	}
        
        
        
?>